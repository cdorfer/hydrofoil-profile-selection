from pathlib import Path


def get_files_paths_ids(path, pattern, sort_files=True):
    """Get files Path-like definition and stem name for a given name pattern.

    Parameters
    ----------
    path : str, Path-like
        Path to parse.
    pattern : str
        Regex-like pattern to select the files.
    sort_files : bool, optional
        Wether to return the files sorted, by default True

    Returns
    -------
    files : pathlib.Path-like list
        List containing the files path.
    ids : str list
        Stem name of the files.
    """

    # Enforce input type
    path = Path(path)

    files = list(path.glob(pattern))

    if sort_files == True:
        files = sorted(files)

    get_name = lambda x: x.name
    ids = list(map(get_name, files))

    return files, ids