import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import viiflowtools.vf_tools as vft
import viiflow as vf
import scipy
from scipy import interpolate


def plot_geometry(ax, p, bl=None, lines=None):
    color_bl = "#37bee8"
    color_geo = "#2d2d2d"
    color_pan = "#c9c9c9"
    if lines is None:
        linesout = []
    else:
        linesout = lines

    # Every wing
    NF = len(p.foils)
    xmin = np.inf
    xmax = -np.inf
    for knf in range(NF):
        # Init list for current wing
        linesoutk = []
        j = 0

        # Panel geometry
        X = p.foils[knf].X.copy()
        if lines is None:
            linesoutk.append(ax.plot(X[0, :], X[1, :], color=color_pan))
        else:
            lines[knf][j][0].set_xdata(X[0, :])
            lines[knf][j][0].set_ydata(X[1, :])

        j += 1

        # Panel + virtual geometry
        X = p.foils[knf].X.copy()
        N = p.foils[knf].normals
        if not p.foils[knf].VD is None:
            N0 = p.foils[knf].VD
            for kvd in range(X.shape[1]):
                for i in range(2):
                    X[i, kvd] += N[i, kvd] * N0[kvd]
        else:
            N0 = p.foils[knf].delta * 0.0

        xmax = max(xmax, np.max(X[0, :]))
        xmin = min(xmin, np.min(X[0, :]))

        if lines is None:
            linesoutk.append(ax.plot(X[0, :], X[1, :], color=color_geo))
        else:
            lines[knf][j][0].set_xdata(X[0, :])
            lines[knf][j][0].set_ydata(X[1, :])

        j += 1

        # If bl, add some stagnation/transition info
        if not bl is None:
            # Stagnation point
            STX = vft.interpLinear(p.foils[knf].S, X[0, :], bl[knf].ST)
            STY = vft.interpLinear(p.foils[knf].S, X[1, :], bl[knf].ST)

            # Upper transition point
            strans = max(bl[knf].ST - bl[knf].bl_fl.node_tr_up.xi, bl[knf].S[0])
            TRUX = vft.interpLinear(p.foils[knf].S, X[0, :], strans)
            TRUY = vft.interpLinear(p.foils[knf].S, X[1, :], strans)

            # Lower transition point
            strans = min(bl[knf].ST + bl[knf].bl_fl.node_tr_lo.xi, bl[knf].S[-1])
            TRLX = vft.interpLinear(p.foils[knf].S, X[0, :], strans)
            TRLY = vft.interpLinear(p.foils[knf].S, X[1, :], strans)

            XX = np.asarray([STX, TRUX, TRLX],dtype=float)
            YY = np.asarray([STY, TRUY, TRLY],dtype=float)

            if lines is None:
                linesoutk.append(ax.plot(XX, YY, "oy"))
            else:
                lines[knf][j][0].set_xdata(XX)
                lines[knf][j][0].set_ydata(YY)
            j += 1

            # Panel + displacement bl
            X = p.foils[knf].X.copy()
            for kvd in range(X.shape[1]):
                for i in range(2):
                    X[i, kvd] += N[i, kvd] * (bl[knf].bl_fl.nodes[kvd].delta + N0[kvd])

            if lines is None:
                linesoutk.append(ax.plot(X[0, :], X[1, :], color=color_bl))
            else:
                lines[knf][j][0].set_xdata(X[0, :])
                lines[knf][j][0].set_ydata(X[1, :])

            j += 1

        # Wake geometry
        XW0 = p.wakes[knf].X.copy()
        N = p.wakes[knf].normals
        if lines is None:
            linesoutk.append(ax.plot(XW0[0, :], XW0[1, :], color=color_pan))
        else:
            lines[knf][j][0].set_xdata(XW0[0, :])
            lines[knf][j][0].set_ydata(XW0[1, :])

        j += 1

        # Basic wake thickness
        # Check for blunt te
        te_thickness = np.sqrt(
            (p.foils[knf].X[0, 0] - p.foils[knf].X[0, -1]) ** 2
            + (p.foils[knf].X[1, 0] - p.foils[knf].X[1, -1]) ** 2
        )

        # Additional virtual displacement thickness
        if not p.foils[knf].VD is None:
            delta_up = te_thickness * 0.5 + p.foils[knf].VD[0]
            delta_lo = te_thickness * 0.5 + p.foils[knf].VD[-1]
            # delta_up = te_thickness*0.5
            # delta_lo = te_thickness*0.5
        else:
            delta_up = te_thickness * 0.5
            delta_lo = te_thickness * 0.5

        delta_up = 0
        delta_lo = 0

        if not bl is None:
            # Wake + BL (2x upper/lower)
            # 1. check ratio upper/lower
            delta_wake = bl[knf].bl_wk.nodes.delta_wake
            delta_raw = bl[knf].bl_wk.nodes.delta - delta_wake
            delta_up += bl[knf].bl_fl.nodes[0].delta
            delta_lo += bl[knf].bl_fl.nodes[-1].delta

            # Additional virtual displacement thickness
            if not p.foils[knf].VD is None:
                delta_up += p.foils[knf].VD[0]
                delta_lo += p.foils[knf].VD[-1]

            if bl[knf].bl_wk.N == XW0.shape[1]:
                for kw in [-1, 1]:
                    if kw == -1:
                        delta_rat = delta_lo
                    else:
                        delta_rat = delta_up
                    ratio = delta_rat / (delta_lo + delta_up)
                    XW = XW0.copy()
                    for kvd in range(XW.shape[1]):
                        for i in range(2):
                            XW[i, kvd] -= 1 * kw * N[i, kvd] * (
                                delta_wake[kvd] * 0.5
                            ) + 1 * kw * ratio * N[i, kvd] * (delta_raw[kvd])

                    if lines is None:
                        linesoutk.append(ax.plot(XW[0, :], XW[1, :], color=color_bl))
                    else:
                        lines[knf][j][0].set_xdata(XW[0, :])
                        lines[knf][j][0].set_ydata(XW[1, :])

                    j += 1
            else:
                XW = XW0.copy()
                XW2 = XW0.copy()
                NW = XW.shape[1]
                for kvd in range(NW):
                    for i in range(2):
                        XW[i, kvd] -= 1 * N[i, kvd] * (bl[knf].bl_wk.nodes[kvd].delta)
                        XW2[i, kvd] += (
                            1 * N[i, kvd] * (bl[knf].bl_wk.nodes[kvd + NW].delta)
                        )

                if lines is None:
                    linesoutk.append(ax.plot(XW[0, :], XW[1, :], color=color_bl))
                    linesoutk.append(ax.plot(XW2[0, :], XW2[1, :], color=color_bl))
                else:
                    lines[knf][j][0].set_xdata(XW[0, :])
                    lines[knf][j][0].set_ydata(XW[1, :])
                    lines[knf][j + 1][0].set_xdata(XW2[0, :])
                    lines[knf][j + 1][0].set_ydata(XW2[1, :])
                j += 2

        # Also important: if available dead air region
        if not bl is None:
            if bl[knf].bl_wk.N == XW0.shape[1]:
                for kw in [-1, 1]:
                    ratio = 0.5
                    XW = XW0.copy()
                    for kvd in range(XW.shape[1]):
                        for i in range(2):
                            XW[i, kvd] -= (
                                1
                                * kw
                                * ratio
                                * N[i, kvd]
                                * (bl[knf].bl_wk.nodes[kvd].delta_wake)
                            )

                    if lines is None:
                        linesoutk.append(ax.plot(XW[0, :], XW[1, :], color=color_pan))
                    else:
                        lines[knf][j][0].set_xdata(XW[0, :])
                        lines[knf][j][0].set_ydata(XW[1, :])

                    j += 1
            else:
                XW = XW0.copy()
                XW2 = XW0.copy()
                NW = XW.shape[1]
                for kvd in range(NW):
                    for i in range(2):
                        XW[i, kvd] -= (
                            1 * N[i, kvd] * (bl[knf].bl_wk.nodes[kvd].delta_wake)
                        )
                        XW2[i, kvd] += (
                            1 * N[i, kvd] * (bl[knf].bl_wk.nodes[kvd + NW].delta_wake)
                        )

                if lines is None:
                    linesoutk.append(ax.plot(XW[0, :], XW[1, :], color=color_pan))
                    linesoutk.append(ax.plot(XW2[0, :], XW2[1, :], color=color_pan))
                else:
                    lines[knf][j][0].set_xdata(XW[0, :])
                    lines[knf][j][0].set_ydata(XW[1, :])
                    lines[knf][j + 1][0].set_xdata(XW2[0, :])
                    lines[knf][j + 1][0].set_ydata(XW2[1, :])
                j += 2

        if lines is None:
            linesout.append(linesoutk)
    ax.axis("equal")
    dx = xmax - xmin
    ax.set_xlim([xmin - 0.1 * dx, xmax + 0.2 * dx])
    return linesout


def max_length(p, bl, x0, y0, nx, ny, kf=None):
    # Check for max displacment thickness
    NF = len(bl)
    # Check all airfoils
    max_thickness = np.inf
    delta_at_thickness = 0.0
    # min_thickness = np.inf
    for j2 in range(NF):
        if not kf is None:
            if kf == j2:
                continue
        FX2 = p.foils[j2].X
        NX2 = p.foils[j2].normals * 1
        delta = bl[j2].bl_fl.nodes.delta
        for i2 in range(FX2.shape[1] - 1):

            # Complete displacement body
            x11 = FX2[0, i2] + NX2[0, i2 + 1] * delta[i2]
            x12 = FX2[0, i2 + 1] + NX2[0, i2 + 1] * delta[i2 + 1]
            y11 = FX2[1, i2] + NX2[1, i2 + 1] * delta[i2]
            y12 = FX2[1, i2 + 1] + NX2[1, i2 + 1] * delta[i2 + 1]
            # check if a*x1+(1-a)*x2 = x0+bn
            # [x1-x2 -n]*[a b] = x0-x2
            detmat = (x11 - x12) * (-ny) - (-nx) * (y11 - y12)

            if detmat == 0:
                print("invalid problem at i2=%u,j2=%u" % (i2, j2))
                continue

            a = (-ny * (x0 - x12) + nx * (y0 - y12)) / detmat
            b = (-(y11 - y12) * (x0 - x12) + (x11 - x12) * (y0 - y12)) / detmat

            if a <= 1 and a >= 0 and b > 0:
                if max_thickness > b:
                    max_thickness = b
                    delta_at_thickness = (delta[i2 + 1] + delta[i2]) / 2
            # if a<=1 and a>=0 and b<0:
            #    min_thickness = np.minimum(min_thickness,b)

        NX2 = -p.wakes[j2].normals
        FX2 = p.wakes[j2].X

        if bl[j2].bl_wk.half_wakes:
            NW = p.wakes[j2].N
            delta_up = bl[j2].bl_wk.nodes[0:NW].delta
            delta_lo = bl[j2].bl_wk.nodes[NW::].delta
        else:
            DET = bl[j2].bl_fl.nodes[0].delta
            DEB = bl[j2].bl_fl.nodes[-1].delta
            delta_up = (DET / (DET + DEB)) * bl[j2].bl_wk.nodes.delta
            delta_lo = (DEB / (DET + DEB)) * bl[j2].bl_wk.nodes.delta

        for i2 in range(FX2.shape[1] - 1):

            # Complete displacement body
            x11 = FX2[0, i2] + NX2[0, i2 + 1] * delta_up[i2]
            x12 = FX2[0, i2 + 1] + NX2[0, i2 + 1] * delta_up[i2 + 1]
            y11 = FX2[1, i2] + NX2[1, i2 + 1] * delta_up[i2]
            y12 = FX2[1, i2 + 1] + NX2[1, i2 + 1] * delta_up[i2 + 1]
            # check if
            # a*x1+(1-a)*x2 = x0+b*n
            # [x1-x2 -n]*[a b] = x0-x2
            detmat = (x11 - x12) * (-ny) - (-nx) * (y11 - y12)

            if detmat == 0:
                continue

            a = (-ny * (x0 - x12) + nx * (y0 - y12)) / detmat
            b = (-(y11 - y12) * (x0 - x12) + (x11 - x12) * (y0 - y12)) / detmat

            if a <= 1 and a >= 0 and b > 0:
                if max_thickness > b:
                    max_thickness = b
                    delta_at_thickness = (delta_up[i2 + 1] + delta_up[i2]) / 2

            # Bottom side

            # Complete displacement body
            x11 = FX2[0, i2] - NX2[0, i2 + 1] * delta_lo[i2]
            x12 = FX2[0, i2 + 1] - NX2[0, i2 + 1] * delta_lo[i2 + 1]
            y11 = FX2[1, i2] - NX2[1, i2 + 1] * delta_lo[i2]
            y12 = FX2[1, i2 + 1] - NX2[1, i2 + 1] * delta_lo[i2 + 1]
            # check if a*x1+(1-a)*x2 = x0+bn
            # [x1-x2 -n]*[a b] = x0-x2
            detmat = (x11 - x12) * (-ny) - (-nx) * (y11 - y12)

            if detmat == 0:
                continue

            a = (-ny * (x0 - x12) + nx * (y0 - y12)) / detmat
            b = (-(y11 - y12) * (x0 - x12) + (x11 - x12) * (y0 - y12)) / detmat

            if a <= 1 and a >= 0 and b > 0:
                if max_thickness > b:
                    max_thickness = b
                    delta_at_thickness = (delta_lo[i2 + 1] + delta_lo[i2]) / 2

    return [max_thickness, delta_at_thickness]


def total_flowfield(p, bl, Nbl, Nin, hy):
    allow_overlap = 1
    FadeStart = 1  # X delta
    FadeEnd = 2.5
    inviscid_residual = (
        0.05  # How much of a limit must be remaining for inviscid points
    )

    # Array of target coordinates
    # All nodes lie in between the node points, and thus e.g. for the foil there are NSG-1 elements
    NSG = p.NS
    NWG = p.NW
    x = np.zeros((NSG - 1 + 2 * (NWG - 1), Nin + Nbl))
    y = np.zeros((NSG - 1 + 2 * (NWG - 1), Nin + Nbl))
    calc_inviscid = np.ones(
        (NSG - 1 + 2 * (NWG - 1), Nin + Nbl), dtype=bool
    )  # This is true if we want to calculate inviscid velocities there.
    NF = len(bl)

    # Geometric series scaled to 1
    q_arithmetic = 1.2
    a_arithmetic = (1 - q_arithmetic) / (1 - q_arithmetic ** (Nin))
    s_arithmetic = (
        a_arithmetic * (1 - q_arithmetic ** np.arange(1, Nin + 1)) / (1 - q_arithmetic)
    )
    # Add these velocities to the global inviscid field

    # Just inviscid (+BL displacement)
    # non-uniform test
    # Go over surface and perpendicular
    YY = []
    UU = []
    VV = []
    DE = []
    offxy = 0
    for kf in range(NF):

        foil = p.foils[kf]
        NS = foil.N
        # Mean surface points and normals
        XFoil = 0.5 * (foil.X[:, 0 : NS - 1] + foil.X[:, 1::])
        NFoil = foil.normals[:, 1:NS]

        wake = p.wakes[kf]
        NW = wake.N
        # Mean wake points and normals
        XWake = 0.5 * (wake.X[:, 0 : NW - 1] + wake.X[:, 1::])
        NWake = -wake.normals[:, 1::]

        # Calculate viscous layer for every airfoil and concatenate
        [Y, U, V] = vf.viscous_flowfield(bl[kf], Nbl)
        delta_fl = bl[kf].bl_fl.nodes.delta
        delta_wk = bl[kf].bl_wk.nodes.delta

        # If we do not use half_wakes, add another half wake and scale
        if not bl[kf].bl_wk.half_wakes:
            DET = bl[kf].bl_fl.nodes[0].delta
            DEB = bl[kf].bl_fl.nodes[-1].delta
            NWI = -int(p.wakes[kf].N - 1)

            facT = DET / (DET + DEB)
            facB = DEB / (DET + DEB)
            Y = np.r_[Y, facB * Y[NWI::, :]]
            U = np.r_[U, U[NWI::, :]]
            V = np.r_[V, V[NWI::, :]]

            Y[NWI * 2 : NWI, :] *= facT

            DEE = np.r_[
                0.5 * (delta_fl[1::] + delta_fl[0:-1]),
                facT * 0.5 * (delta_wk[1::] + delta_wk[0:-1]),
                facB * 0.5 * (delta_wk[1::] + delta_wk[0:-1]),
            ]

        else:
            DEE = np.r_[
                0.5 * (delta_fl[1::] + delta_fl[0:-1]),
                0.5 * (delta_wk[1:NW] + delta_wk[0 : NW - 1]),
                0.5 * (delta_wk[NW:-1] + delta_wk[NW + 1 : :]),
            ]

        YY.append(Y)
        UU.append(U)
        VV.append(V)
        DE.append(DEE)

        for k in range(NS - 1):
            [hy_max, delta_at_hy] = max_length(
                p, bl, XFoil[0, k], XFoil[1, k], NFoil[0, k], NFoil[1, k], kf
            )

            # if we are limited, the ratio between the two sides should be comparable to their deltas
            delta = DE[kf][k]
            rat = delta / (delta + delta_at_hy)

            hy_local = np.minimum(hy_max * allow_overlap * rat, hy)

            # Re-interpolate BL solution to 90% max size
            if YY[kf][k, -1] > (1 - inviscid_residual) * hy_local:
                fac = ((1 - inviscid_residual) * hy_local) / YY[kf][k, -1]
                UU[kf][k, :] = np.interp(fac * YY[kf][k, :], YY[kf][k, :], UU[kf][k, :])
                VV[kf][k, :] = np.interp(fac * YY[kf][k, :], YY[kf][k, :], VV[kf][k, :])
                YY[kf][k, :] *= fac

            # BL region
            x[offxy + k, 0:Nbl] = XFoil[0, k] + YY[kf][k, :] * NFoil[0, k]
            y[offxy + k, 0:Nbl] = XFoil[1, k] + YY[kf][k, :] * NFoil[1, k]

            calc_inviscid[offxy + k, 0:Nbl] = YY[kf][k, :] > DE[kf][k]

            # inviscid region
            s = YY[kf][k, -1] + s_arithmetic * (hy_local - YY[kf][k, -1])
            x[offxy + k, Nbl::] = XFoil[0, k] + s * NFoil[0, k]
            y[offxy + k, Nbl::] = XFoil[1, k] + s * NFoil[1, k]

        for k in range(NS - 1, NS - 1 + NW - 1):
            kw = k - NS + 1  # index in wake array
            [hy_max, delta_at_hy] = max_length(
                p, bl, XWake[0, kw], XWake[1, kw], NWake[0, kw], NWake[1, kw], kf
            )
            delta = DE[kf][k]
            rat = delta / (delta + delta_at_hy)
            hy_local = np.minimum(hy_max * allow_overlap * rat, hy)

            # Constrain YY
            # Re-interpolate BL solution to 90% max size
            if YY[kf][k, -1] > (1 - inviscid_residual) * hy_local:
                fac = ((1 - inviscid_residual) * hy_local) / YY[kf][k, -1]
                UU[kf][k, :] = np.interp(fac * YY[kf][k, :], YY[kf][k, :], UU[kf][k, :])
                VV[kf][k, :] = np.interp(fac * YY[kf][k, :], YY[kf][k, :], VV[kf][k, :])
                YY[kf][k, :] *= fac

            # BL region
            x[offxy + k, 0:Nbl] = XWake[0, kw] + YY[kf][k, :] * NWake[0, kw]
            y[offxy + k, 0:Nbl] = XWake[1, kw] + YY[kf][k, :] * NWake[1, kw]

            calc_inviscid[offxy + k, 0:Nbl] = YY[kf][k, :] > DE[kf][k]

            # inviscid region
            s = YY[kf][k, -1] + s_arithmetic * (hy_local - YY[kf][k, -1])

            x[offxy + k, Nbl::] = XWake[0, kw] + s * NWake[0, kw]
            y[offxy + k, Nbl::] = XWake[1, kw] + s * NWake[1, kw]

            # If half_wake, this is actually from a different Y
            offY = NW - 1

            [hy_max, delta_at_hy] = max_length(
                p, bl, XWake[0, kw], XWake[1, kw], -NWake[0, kw], -NWake[1, kw], kf
            )
            delta = DE[kf][offY + k]
            rat = delta / (delta + delta_at_hy)
            hy_local = np.minimum(hy_max * allow_overlap * rat, hy)

            # Constrain YY
            # Re-interpolate BL solution to 90% max size
            if YY[kf][offY + k, -1] > (1 - inviscid_residual) * hy_local:
                fac = ((1 - inviscid_residual) * hy_local) / YY[kf][offY + k, -1]
                UU[kf][offY + k, :] = np.interp(
                    fac * YY[kf][offY + k, :], YY[kf][offY + k, :], UU[kf][offY + k, :]
                )
                VV[kf][offY + k, :] = np.interp(
                    fac * YY[kf][offY + k, :], YY[kf][offY + k, :], VV[kf][offY + k, :]
                )
                YY[kf][offY + k, :] *= fac

            x[offxy + k + (NW - 1), 0:Nbl] = (
                XWake[0, kw] - YY[kf][offY + k, :] * NWake[0, kw]
            )
            y[offxy + k + (NW - 1), 0:Nbl] = (
                XWake[1, kw] - YY[kf][offY + k, :] * NWake[1, kw]
            )

            calc_inviscid[offxy + k + (NW - 1), 0:Nbl] = (
                YY[kf][offY + k, :] > DE[kf][offY + k]
            )

            # inviscid region
            s = YY[kf][offY + k, -1] + s_arithmetic * (hy_local - YY[kf][offY + k, -1])

            x[offxy + k + (NW - 1), Nbl::] = XWake[0, kw] - s * NWake[0, kw]
            y[offxy + k + (NW - 1), Nbl::] = XWake[1, kw] - s * NWake[1, kw]

        offxy += NS - 1 + 2 * (NW - 1)

    # Save some time by only calculating points>delta
    X = np.c_[x.ravel(), y.ravel()].T
    VELI = X.copy(order="F") * 0
    XI = X[:, np.flatnonzero(calc_inviscid.ravel())]
    VEI = VELI[:, np.flatnonzero(calc_inviscid.ravel())]
    # vf.inviscid_velocity(p,X,VELI)
    vf.inviscid_velocity(p, XI, VEI)
    VELI[:, np.flatnonzero(calc_inviscid.ravel())] = VEI

    UI = np.reshape(VELI[0, :], (NSG - 1 + 2 * (NWG - 1), Nin + Nbl))
    VI = np.reshape(VELI[1, :], (NSG - 1 + 2 * (NWG - 1), Nin + Nbl))

    # Replace UI/VI where BL is
    offxy = 0
    for kf in range(NF):
        NS = p.foils[kf].N

        # Mean surface points and normals
        foil = p.foils[kf]
        XFoil = 0.5 * (foil.X[:, 0 : NS - 1] + foil.X[:, 1::])
        NFoil = foil.normals[:, 1:NS]

        for k in range(NS - 1):
            if p.foils[kf].S[k] < bl[kf].ST:
                signum = -1
            else:
                signum = 1

            n0 = np.asarray(np.reshape(NFoil[:, k], (2, 1)))
            t0 = np.array([[0, -1], [1, 0]]) @ n0

            DY = (YY[kf][k, :] - FadeStart * DE[kf][k]) / (
                (FadeEnd - FadeStart) * DE[kf][k]
            )
            override = 1 - np.minimum(np.maximum(DY, 0), 1)
            v = np.minimum(np.maximum(VV[kf][k, :], -3), 3)
            UI[offxy + k, 0:Nbl] += override * (
                signum * UU[kf][k, :] * t0[0] + v * n0[0] - UI[offxy + k, 0:Nbl]
            )
            VI[offxy + k, 0:Nbl] += override * (
                signum * UU[kf][k, :] * t0[1] + v * n0[1] - VI[offxy + k, 0:Nbl]
            )

        wake = p.wakes[kf]
        NW = wake.N
        # Mean wake points and normals
        XWake = 0.5 * (wake.X[:, 0 : NW - 1] + wake.X[:, 1::])
        NWake = -wake.normals[:, 1::]

        for k in range(NS - 1, NS - 1 + NW - 1):
            signum = 1
            kw = k - NS + 1
            n0 = np.asarray(np.reshape(NWake[:, kw], (2, 1)))
            t0 = -np.array([[0, -1], [1, 0]]) @ n0

            DY = (YY[kf][k, :] - FadeStart * DE[kf][k]) / (
                (FadeEnd - FadeStart) * DE[kf][k]
            )
            override = 1 - np.minimum(np.maximum(DY, 0), 1)
            v = np.minimum(np.maximum(VV[kf][k, :], -3), 3)
            UI[offxy + k, 0:Nbl] += override * (
                signum * UU[kf][k, :] * t0[0] + v * n0[0] - UI[offxy + k, 0:Nbl]
            )
            VI[offxy + k, 0:Nbl] += override * (
                signum * UU[kf][k, :] * t0[1] + v * n0[1] - VI[offxy + k, 0:Nbl]
            )

            offY = NW - 1

            DY = (YY[kf][offY + k, :] - FadeStart * DE[kf][offY + k]) / (
                (FadeEnd - FadeStart) * DE[kf][offY + k]
            )
            override = 1 - np.minimum(np.maximum(DY, 0), 1)
            v = np.minimum(np.maximum(VV[kf][offY + k, :], -3), 3)
            UI[offxy + k + NW - 1, 0:Nbl] += override * (
                signum * UU[kf][offY + k, :] * t0[0]
                - v * n0[0]
                - UI[offxy + k + NW - 1, 0:Nbl]
            )
            VI[offxy + k + NW - 1, 0:Nbl] += override * (
                signum * UU[kf][offY + k, :] * t0[1]
                - v * n0[1]
                - VI[offxy + k + NW - 1, 0:Nbl]
            )

        offxy += NS - 1 + 2 * (NW - 1)

    # For Mulit_element airfoils, the wakes may be closer to each other than the nodes ares distanced. Which leads to artifacts.
    # Add some points here.
    if NF > 1:
        offxy = 0
        RF = 2

        for kf in range(NF):
            NS = p.foils[kf].N
            NW = p.wakes[kf].N
            xi = 0.5 * (bl[kf].bl_wk.nodes[0 : NW - 1].xi + bl[kf].bl_wk.nodes[1:NW].xi)
            Nxi = len(xi)
            xiNew = np.linspace(xi[0], xi[-1], RF * Nxi)

            offxy += NS - 1
            # Interpolate upper side
            xw = scipy.interpolate.interp1d(xi, x[offxy + 0 : offxy + Nxi, :], axis=0)(
                xiNew
            )
            yw = scipy.interpolate.interp1d(xi, y[offxy + 0 : offxy + Nxi, :], axis=0)(
                xiNew
            )
            UIw = scipy.interpolate.interp1d(
                xi, UI[offxy + 0 : offxy + Nxi, :], axis=0
            )(xiNew)
            VIw = scipy.interpolate.interp1d(
                xi, VI[offxy + 0 : offxy + Nxi, :], axis=0
            )(xiNew)

            # Add to array
            x = np.r_[x, xw]
            y = np.r_[y, yw]
            UI = np.r_[UI, UIw]
            VI = np.r_[VI, VIw]

            # Interpolate lower side
            xw = scipy.interpolate.interp1d(
                xi, x[offxy + 0 + NW - 1 : offxy + Nxi + NW - 1, :], axis=0
            )(xiNew)
            yw = scipy.interpolate.interp1d(
                xi, y[offxy + 0 + NW - 1 : offxy + Nxi + NW - 1, :], axis=0
            )(xiNew)
            UIw = scipy.interpolate.interp1d(
                xi, UI[offxy + 0 + NW - 1 : offxy + Nxi + NW - 1, :], axis=0
            )(xiNew)
            VIw = scipy.interpolate.interp1d(
                xi, VI[offxy + 0 + NW - 1 : offxy + Nxi + NW - 1, :], axis=0
            )(xiNew)

            # Add to array
            x = np.r_[x, xw]
            y = np.r_[y, yw]
            UI = np.r_[UI, UIw]
            VI = np.r_[VI, VIw]

            offxy += 2 * (NW - 1)
    return [x, y, UI, VI]


"""
 # Calculate short streamlines
def calc_streamlines(x,y,UI,VI,numParallel,numNormal):
    # Define triangulatioon from grid 
    intpU = scipy.interpolate.LinearNDInterpolator(np.c_[x.ravel(),y.ravel()], UI.ravel(), fill_value=np.nan, rescale=False)
    intpV = scipy.interpolate.LinearNDInterpolator(np.c_[x.ravel(),y.ravel()], VI.ravel(), fill_value=np.nan, rescale=False)

    [N,M] = x.shape

    # Set an x0 and interpolate along
    # We use the original grid, with steps
    stepXi = int(N/numParallel)
    stepHi = int(M/numNormal)
    NStrDisc = 200
    x_max = np.amax(x.ravel())
    x_min = np.amin(x.ravel())



    # Check length
    NStreams = 0
    for k in range(1,N,stepXi):
        for j in range(1,M,stepHi):
            NStreams+=1

    XStream = np.zeros((NStreams,NStrDisc))
    YStream = np.zeros((NStreams,NStrDisc))
    # x0
    index = -1
    for k in range(1,N,stepXi):
        for j in range(1,M,stepHi):
            index +=1
            XStream[index,0] = x[k,j]
            YStream[index,0] = y[k,j]

    for k in range(NStrDisc-1):
        u = intpU(XStream[:,k],YStream[:,k])
        v = intpV(XStream[:,k],YStream[:,k])
        nuv = np.sqrt(u**2+v**2)+1e-9
        XStream[:,k+1] = XStream[:,k] - u/nuv*(x_max-x_min)*3e-4
        YStream[:,k+1] = YStream[:,k] - v/nuv*(x_max-x_min)*3e-4
    
    return [XStream.T,YStream.T]
"""
