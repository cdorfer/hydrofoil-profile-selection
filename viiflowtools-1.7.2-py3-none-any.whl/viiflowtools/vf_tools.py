import numpy as np
from numpy.core.multiarray import interp


def spl_tri_mat(x):
    # This implements the matrix operator for natural cubic splines
    # This is directly copied from the (German) wikipedia page (Oct. 2019)
    h = np.diff(x)
    # Build the tridiagonal matrix
    ld = np.empty_like(h)  # lower diagonal
    md = np.empty_like(x)  # main diagonal
    ud = np.empty_like(h)  # upper diagonal

    # As in wikipedia
    ld = h / 6
    md[1:-1] = (h[:-1] + h[1:]) / 3
    ud = h / 6

    # Natural boundary conditions
    ud[0] = 0
    md[0] = 1
    # End
    md[-1] = 1
    ld[-1] = 0

    # Hermite boundary conditions
    # This means that the TE is always of the same angle
    md[0] = h[0] / 3  # mu_0
    md[-1] = h[-1] / 3  # mu_n
    ud[0] = h[0] / 6  # lam_0
    ld[-1] = h[-1] / 6  # lam_n

    return h, ld, md, ud


def rhs(h, y):
    # This implements the RHS for natural cubic splines
    # This is copied from the (German) wikipedia page (Oct. 2019)

    q = np.diff(y) / h
    b = np.empty_like(y)
    b[..., 1:-1] = q[..., 1:] - q[..., :-1]

    """
    # Natural boundary conditions
    b[...,0] = 0
    b[...,-1] = 0
    """

    # Hermite boundary conditions
    b[..., 0] = 0  # b0
    b[..., -1] = 0  # bn

    return b


def poly_eval_single(index, s, x, y, M):
    # This implements the spline evaluation for natural cubic splines
    # This is copied from the (German) wikipedia page (Oct. 2019)

    i = index
    h = x[i + 1] - x[i]
    Mi = M[i]
    Mi1 = M[i + 1]

    # 2nd derivative
    y2n = (h - s) / h * Mi + s / h * Mi1

    # 1st derivative
    c_i = (y[i + 1] - y[i]) / h - h / 6 * (Mi1 - Mi)
    y1n = 1 / 2 * (-((h - s) ** 2) / h * Mi + s ** 2 / h * Mi1) + c_i

    # Evaluation
    d_i = y[i] - h ** 2 / 6 * Mi
    yn = 1 / 6 * ((h - s) ** 3 / h * Mi + s ** 3 / h * Mi1) + c_i * s + d_i

    return yn, y1n, y2n


def spline_moments(X, S):
    # This implements the spline evaluation for natural cubic splines
    # This is copied from the (German) wikipedia page (Oct. 2019)

    # Spline matrix for moments M
    h, ld, md, ud = spl_tri_mat(S)
    # But we need to solve the matrix twice, for X and for Y
    # I did not find a nice numpy tridiag solver ?
    A = np.diag(ld, -1) + np.diag(md, 0) + np.diag(ud, 1)
    RHS = rhs(h, X)
    if len(X.shape) > 1:
        M_spl = np.linalg.solve(A, RHS.T).T
    else:
        M_spl = np.linalg.solve(A, RHS)
    return M_spl


def spline_locate(S, s):
    """
    j = 0  # index in S
    while j < len(S) - 2 and s > S[j + 1]:
        j += 1  # Go to next bracket
    """

    j = min(S[1::].searchsorted(s), len(S) - 2)
    # print(j,len(S))

    return (j, min(s, S[-1]) - S[j])


def spline_eval(X, S, M_spl, SN):

    NN = len(SN)
    XN = np.zeros((2, NN))
    for k in range(len(SN)):
        XN[0, k], XN[1, k], _, _, _ = spline_eval_single(X, S, M_spl, SN[k])
    return XN


def spline_eval_single(X, S, M_spl, s):
    j, si = spline_locate(S, s)

    xn, x1n, x2n = poly_eval_single(j, si, S, X[0, :], M_spl[0, :].transpose())
    yn, y1n, y2n = poly_eval_single(j, si, S, X[1, :], M_spl[1, :].transpose())

    # Calculate curvature
    Kap = (x1n * y2n - x2n * y1n) / (x1n ** 2.0 + y1n ** 2.0) ** (1.5)
    return xn, yn, Kap, x1n, y1n


def read_selig(filepath):
    X = np.loadtxt(filepath, skiprows=1)
    X = X.T
    assert len(X.shape) == 2
    assert X.shape[0] == 2
    return X


def interpSpline(X, Y, XN):

    # Matrix operator
    h, ld, md, ud = spl_tri_mat(X)
    # But we need to solve the matrix twice, for X and for Y
    # I did not find a nice numpy tridiag solver
    A = np.diag(ld, -1) + np.diag(md, 0) + np.diag(ud, 1)
    RHS = rhs(h, Y)
    M_spl = np.linalg.solve(A, RHS)
    YN = np.empty_like(XN)
    for k in range(len(YN)):
        j, si = spline_locate(X, XN[k])
        YN[k], _, _ = poly_eval_single(j, si, X, Y, M_spl)
    return YN


def interpLinear(X, Y, XN):
    return np.interp(XN, X, Y)


def repanel_spline(X, N):

    # Get the airfoil surface variable S
    N0 = X.shape[1]
    S = np.zeros(N0)
    for k in range(1, N0):
        U = X[:, k] - X[:, k - 1]
        nU = np.sqrt(U[0] ** 2 + U[1] ** 2)
        S[k] = S[k - 1] + nU
    # Get a new airfoil surface variable SR, with the same "density" but more
    # or less points

    SR = interpSpline(np.arange(0, len(S)) / (len(S) - 1), S, (np.arange(N)) / (N - 1))

    # Interpolate along new SR
    XR = np.zeros((2, N))
    XR[0, :] = interpSpline(S, X[0, :], SR)
    XR[1, :] = interpSpline(S, X[1, :], SR)

    return XR


def normalize_geometry(X):
    imin = np.argmin(X[0, :])
    xmin = X[0, imin]
    X[0, :] = X[0, :] - xmin
    X = X / max(X[0, :])
    X[1, :] = X[1, :] - X[1, imin]
    return X


def surface_variable(X, d=None):

    # Check for OK size of airfoils shape
    assert X.shape[0] == 2

    N = X.shape[1]
    assert N > 10, "Not enough points for suitable geometry"

    S = np.zeros(N)
    normals = np.zeros((2, N))

    U = np.c_[
        (X[:, 1] - X[:, 0]) * 2,
        X[:, 2::] - X[:, 0 : N - 2],
        (X[:, N - 1] - X[:, N - 2]) * 2,
    ]
    nU = np.sqrt(np.sum(U ** 2, 0))
    normals[0, :] = U[1, :] / nU
    normals[1, :] = -U[0, :] / nU
    normals[:, nU == 0] = 0
    S = np.cumsum(nU / 2)

    if not d is None:
        assert d.shape[0] == N
        Xd = X.copy()
        for j in range(N):
            Xd[:, j] += N * d[j]
        [S, _] = surface_variable(Xd)

    return [S, normals]


def virtual_displacement_from_geometry(X0, X1):
    """Find virtual displacements to modify an input airfoil X0 to be close to a desired shape X1.
    That is, this calculates an array of distances called "virtual displacements" that if added to X0 normal
    to the panels results in an airfoil very close to the airfoil X1.


    Parameters
    -----------
    X0 :  2xN0 float array, Base airfoil coordinates.
    X1 :  2xN1 float array, Desired airfoil coordinates.

    Returns
    --------
    delta : N0 float array, Virtual displacement array.
    Xd : 2xN0 float array, Base airfoil plus geometry modification due to delta.
    """

    tol = 1e-2

    # General info
    [S0, N0] = surface_variable(X0)
    n0 = len(S0)
    [S1, _] = surface_variable(X1)
    n1 = len(S1)

    delta0 = np.zeros(n0)

    # Go over top
    j0 = 0
    A = np.zeros((2, 2))
    DX = np.diff(X1, 1, axis=1)
    DXN = np.sum(DX ** 2, axis=0)
    x = np.zeros(2)
    for k in range(n0):
        delta0[k] = 0
        minDist = np.inf
        minarg = -1
        mindelta = 0
        # Solve linear problem of straight line crossing straight line
        # -Normal[:,k]*d + (X[:,j]-X[:,j-1]])*b =
        # Problem: xk+d*N = a*X(j+1) + (1-a)*X(j)
        # xk -xj = a*(X(j+1)-*X(j))-d*N
        # dx = X1[:, j] - X1[:, j + 1]
        A[:, 0] = -N0[:, k]
        for j in range(j0, (n1 - 1)):
            if DXN[j] == 0:
                continue

            A[:, 1] = -DX[:, j]
            b = X0[:, k] - X1[:, j + 1]
            
            # If we have an exact match, break
            if np.sqrt(b[0]**2+b[1]**2)<1e-9:
                mindelta = 0
                minarg = j+1
                break
            

            # Manual solve of 2x2 system
            detA = A[0, 0] * A[1, 1] - A[0, 1] * A[1, 0]
            if abs(detA) > 1e-14:
                x[0] = (A[1, 1] * b[0] - A[0, 1] * b[1]) / detA
                x[1] = (-A[1, 0] * b[0] + A[0, 0] * b[1]) / detA
            else:
                continue

            # If we have an "exact" match, set to -1. Otherwise, calculate "distance"
            if x[1] >= -tol and (x[1] <= 1.0 + tol):
                currDist = -1
            else:
                currDist = (DXN[j] * min(abs(x[1]), abs(x[1] - 1))) ** 2 + x[0] ** 2 + 100*(S0[k]-S1[j])**2

            # If this is an exact match or a small distance, assign to current best guess
            if currDist < minDist:
                minDist = currDist
                minarg = j
                mindelta = x[0]

            # On exact match, break
            if currDist < 0:
                break

        # Assign best guess (after going through all or on exact match)
        j0 = max(minarg - 1, 0)
        delta0[k] = mindelta

    Xd = X0.copy()
    Xd += N0 * delta0

    return (delta0, Xd)


def repanel_equidistant(X, N):
    """Repanel a airfoil coordinates along the arclength with equidistant length distances to a desired number of nodes.


    Parameters
    -----------
    X :  2xN0 float array, Airfoil coordinates
    N :  int, Desired number of output coordinates

    Returns
    --------
    XN : 2xN float array, New arifoil coordinates.
    """

    # The Curvature is given at panels S.
    # Rescale to 0->1, and rescale at the end.
    XMIN = np.amin(X[0, :])
    XMAX = np.amax(X[0, :])
    X[0, :] -= XMIN
    X /= XMAX - XMIN

    (S, M_spl) = spline_base(X)
    SN = np.linspace(0, S[-1], N)
    XN = spline_eval(X, S, M_spl, SN)

    # Rescale
    XN *= XMAX - XMIN
    XN[0, :] += XMIN
    return XN


def circumradius_3points(x1, x2, x3, y1, y2, y3):
    """Calculate circle radius through 3 points given by 3 (x,y) pairs
    See https://en.wikipedia.org/wiki/Circumscribed_circle#Other_properties

    Parameters
    -----------
    x1 : float
    x2 : float
    x3 : float
    y1 : float
    y2 : float
    y3 : float

    Returns
    --------
    radius : float
    """

    # Calculate length of triangle sides
    [a, b, c] = [
        np.sqrt(dx ** 2 + dy ** 2)
        for (dx, dy) in zip([x2 - x1, x3 - x2, x1 - x3], [y2 - y1, y3 - y2, y1 - y3])
    ]
    s = (a + b + c) / 2.0  # semiperimenter
    area_squared = (
        s * (s - a) * (s - b) * (s - c)
    )  # Heron's formula ("unstable" variant)
    if area_squared > 0:
        radius = a * b * c / 4.0 / np.sqrt(area_squared)
    else:
        radius = 0
    return radius


def DF2(
    X,
    S,
    M_spl,
    s,
    LEFAC=2.0,
    TEFAC=0.5,
    KAPFAC=0.5,
    REFLIMS=np.asarray([1.0, 1.0, 1.0, 1.0]),
    REFVAL=0.0,
):
    """Helper function that calculates the panel distance at a certain point along the arclength S,
    given the airfoil coordinates and spline moments, as well as the weighting factors.
    The weighting factors are read as: 0 means ignore/no refinement and should be increased to larger values.
    The larger the more refined due to this value, and the value should be among the single digits.
    Like 1, or 2 or 4.34.

    Parameters
    -----------
    X :  2xN float array, Airfoil coordinates.
    S :  N float array, Arclength at every airfoil coordinate.
    M_spl : 2xN float array, Spline moments for x,y position.
    s : float, Arclength position where the panel distance should be calculated.
    LEFAC : float, Weighting factor for leading edge density.
    TEFAC : float, Weighting factor for trailing edge density.
    KAPFAC: float, Weighting factor for curvature of airfoil.
    REFLIMS: 4D float array, arclength positions of areas to be refined. First two and last two define the area.
    REFVAL: float, Weighting factor for refined areas.

    Returns
    --------
    Dens : float, panel distance at arclength s
    """
    PC = 1#0.75

    # Calculate curvature using circumradius
    width = 0.02
    se = min(max(s + width / 3, width), S[-1] - width)
    x1, y1, _, _, _ = spline_eval_single(X, S, M_spl, se)
    x0, y0, _, _, _ = spline_eval_single(X, S, M_spl, se - width)
    x2, y2, _, _, _ = spline_eval_single(X, S, M_spl, se + width)
    radius = circumradius_3points(x0, x1, x2, y0, y1, y2)
    if radius <= 1e-3:
        KAP = 1e3
    elif radius > 10:
        KAP = 0.1
    else:
        KAP = 1.0 / radius

    se = min(max(s - width / 3, width), S[-1] - width)
    x1, y1, _, _, _ = spline_eval_single(X, S, M_spl, se)
    x0, y0, _, _, _ = spline_eval_single(X, S, M_spl, se - width)
    x2, y2, _, _, _ = spline_eval_single(X, S, M_spl, se + width)
    radius = circumradius_3points(x0, x1, x2, y0, y1, y2)
    if radius <= 1e-3:
        KAP1 = 1e3
    elif radius > 10:
        KAP1 = 0.1
    else:
        KAP1 = 1.0 / radius

    KAP = np.sqrt(KAP ** 2 + KAP1 ** 2)

    # Evaluate at s (not constrained as above)
    x, _, _, _, _ = spline_eval_single(X, S, M_spl, s)

    # Increase density at trailing edge/leading edge
    FUNLETE = (
        TEFAC ** 2 * (1 - np.fmin(10 * (1.0 - x), 1.0)) ** 2
        + LEFAC ** 2 * (1 - np.fmin(10 * x, 1.0)) ** 3
    )

    # Scale curvature factor by estimate of some inv radius
    MeanKap = 1.0 / 5.0
    Dens = (0.5 + KAPFAC * ((KAP / MeanKap) ** PC) + FUNLETE) ** -0.5
    R = 0.0
    ds = 0.05

    # Smooth refinement start/end over ds
    if REFLIMS[1] < REFLIMS[0]:
        R_up = (
            np.interp(
                s,
                [REFLIMS[1] - ds, REFLIMS[1], REFLIMS[0], REFLIMS[0] + ds],
                [0.0, 1.0, 1.0, 0.0],
            )
            ** 3
        )
    else:
        R_up = 0
    if REFLIMS[2] < REFLIMS[3]:
        R_lo = (
            np.interp(
                s,
                [REFLIMS[2] - ds, REFLIMS[2], REFLIMS[3], REFLIMS[3] + ds],
                [0.0, 1.0, 1.0, 0.0],
            )
            ** 3
        )
    else:
        R_lo = 0
    R = min(
        R_up + R_lo, 1.0
    )  # At LE, we may have defined the refinement on both sides. Adding them over the smoothing area may lead to facors>1

    Dens = (Dens ** -2 + (R * 3 * (REFVAL) ** 2)) ** -0.5
    return Dens


def spline_base(X):
    # Define spline interpolation based in linear distance arclength approximation
    ND = X.shape[1]
    S0 = np.zeros(ND)
    for k in range(1, ND):
        S0[k] = S0[k - 1] + np.sqrt(
            (X[0, k] - X[0, k - 1]) ** 2 + (X[1, k] - X[1, k - 1]) ** 2
        )
    M_spl = spline_moments(X, S0)

    #'''
    # Calculate derivatives at spline nodes and midpoints, and accumulate for actual spline arclength
    S = np.zeros(ND)
    for k in range(1, ND):
        # Simpson rule:
        # \int_S0(i)^S0(i+1) \sqrt{X'^2+Y'^2}
        # = (S0(i+1)-S0(i))/6 * (\sqrt{X(i)'^2+Y(i)'^2} + 4 \sqrt{X(i+1/2)'^2+Y(i+1/2)'^2} + \sqrt{X(i+1)'^2+Y(i+1)'^2})
        # We could have saved one evaluation here by re-using last k. But no significant saving and more readable.
        _, _, _, dx0, dy0 = spline_eval_single(X, S0, M_spl, S0[k - 1])
        _, _, _, dx1, dy1 = spline_eval_single(X, S0, M_spl, S0[k])
        _, _, _, dx12, dy12 = spline_eval_single(
            X, S0, M_spl, 0.5 * (S0[k] + S0[k - 1])
        )
        S[k] = S[k - 1] + (S0[k] - S0[k - 1]) / 6 * (
            np.sqrt(dx0 ** 2 + dy0 ** 2)
            + 4 * np.sqrt(dx12 ** 2 + dy12 ** 2)
            + np.sqrt(dx1 ** 2 + dy1 ** 2)
        )

    # Re-spline at real arclength
    M_spl = spline_moments(X, S)
    #'''

    return (S, M_spl)


def repanel(
    X, N=180, LEFAC=2.0, TEFAC=1.0, KAPFAC=0.5, REFLIMS=[1.0, 1.0, 1.0, 1.0], REFVAL=0.0
):
    """Repanel a airfoil coordinates along the arclength given the weighting factors that define where the
    distance between coordinates should be small by increasing the factors.
    The weighting factors are read as: 0 means ignore/no refinement and should be increased to larger values.
    The larger the more refined due to this value, and the value should be among the single digits.
    Like 1, or 2 or 4.34.


    Parameters
    -----------
    X :  2xN0 float array, Airfoil coordinates
    N :  int, Desired number of output coordinates
    LEFAC : float, Weighting factor for leading edge density.
    TEFAC : float, Weighting factor for trailing edge density.
    KAPFAC: float, Weighting factor for curvature of airfoil.
    REFLIMS: 4D float array, x positions of areas to be refined on suction and pressure side.
             First two and last two define the area (xmin,xmax,xmin,xmax).
    REFVAL: float, Weighting factor for refined areas. 0: No refinement.

    Returns
    --------
    XN : 2xN float array, New airfoil coordinates.
    """

    # Rescale to chord positions 0->1, and rescale at the end.
    XMIN = np.amin(X[0, :])
    XMAX = np.amax(X[0, :])
    X[0, :] -= XMIN
    X /= XMAX - XMIN

    # Check inputs
    REFLIMSNP = np.asarray(REFLIMS) / (XMAX - XMIN)
    REFLIMSNP = np.fmin(REFLIMSNP, XMAX)
    REFLIMSNP = np.fmax(REFLIMSNP, XMIN)

    ND = X.shape[1]

    (S, M_spl) = spline_base(X)

    # Find LE s
    indexLE = np.argmin(X[0, :])

    # Calculate refinement limits in terms of arclength positions
    for k in [0, 1]:
        REFLIMSNP[k] = np.interp(REFLIMS[k], X[0, indexLE::-1], S[indexLE::-1])
    for k in [2, 3]:
        REFLIMSNP[k] = np.interp(REFLIMS[k], X[0, indexLE::], S[indexLE::])

    # Calculate density function at 2x the given node amount
    n_sample = 4
    density_samples = np.zeros(n_sample * ND - (n_sample-1))
    S_samples = np.zeros(n_sample * ND - (n_sample-1))
    for k in range(ND):
        S_samples[n_sample * k] = S[k]
        density_samples[n_sample * k] = DF2(
            X, S, M_spl, S[k], LEFAC, TEFAC, KAPFAC, REFLIMSNP, REFVAL
        )
        if k < (ND - 1):
            for j in range(1,n_sample):
                S_samples[n_sample * k + j] = S[k]*(1-j/n_sample) + S[k + 1]*j/n_sample
                density_samples[n_sample * k + j] = DF2(
                    X,
                    S,
                    M_spl,
                    S_samples[n_sample * k + j],
                    LEFAC,
                    TEFAC,
                    KAPFAC,
                    REFLIMSNP,
                    REFVAL,
                )

    # Make the trailing edge densities very similar by smoothing over the width
    width = 0.05
    density_mean = (
        np.sqrt(
            0.5 * density_samples ** -2
            + 0.5
            * np.interp(S_samples[-1] - S_samples, S_samples, density_samples) ** -2
        )
        ** -1
    )
    density_samples = (
        interp(
            S_samples,
            np.asarray(
                [0, width, S_samples[-1] - width, S_samples[-1]], dtype=np.float64
            ),
            np.asarray([1.0, 0.0, 0.0, 1.0], dtype=np.float64),
        )
        * density_mean
        + interp(
            S_samples,
            np.asarray(
                [0, width, S_samples[-1] - width, S_samples[-1]], dtype=np.float64
            ),
            np.asarray([0.0, 1.0, 1.0, 0.0], dtype=np.float64),
        )
        * density_samples
    )

    # Evaluation: Simple interpolation to density function at sample points
    # IT = lambda s: np.interp(max(0, min(s, S_samples[-1])), S_samples, density_samples)

    # Initial gamma
    # Rough estimate on length at scale 1
    S0 = 0.0
    for k in range(N):
        # S0 += IT(k * S[-1] / (N - 1))
        S0 += interp(k * S[-1] / (N - 1), S_samples, density_samples)
    gamma = S[-1] / S0

    # Iteration
    converged = 0
    SR = np.zeros(N)
    delIT = 1e-12  # For finite difference calculation, stepsize along arclength

    maxDS = 0.0
    minDS = np.inf

    iterations_fixed_point = 10
    iteration_newton_max = 300
    eval_points = np.zeros(3)
    for it in range(iteration_newton_max):
        SEND_GAM = 0
        all_converged = True
        for k in range(1, N):  # initial S is 0

            # TE Ratio
            TERat = 0.6
            if k == 2:
                DS /= TERat
                DS_S = 0  # The stepsize is given by TE constraints and previous DS
                DS_gam = 0
            elif k == N - 1:
                DS *= TERat
                DS_S = 0
                DS_gam = 0
            else:
                # If at first node, evaluate at next node half and assume TERAT
                # Then we need to scale after finding the midpoint in the next node
                # Otherwise, just find the midpoint
                if k == 1:
                    stpsz = TERat + 0.5
                else:
                    stpsz = 0.5
                # Problem: S[k] = S[k-1] + DS
                #          DS = gamma*IT(0.5*S[k]+0.5*S[k-1])
                #          0 = gamma*IT(0.5*(S[k-1] + DS)+0.5*S[k-1]) - DS
                # DS0 = IT(SR[k - 1])  # Initial value
                DS0 = interp(SR[k - 1], S_samples, density_samples)
                DS = DS0
                subconverged = False
                for subit in range(100):
                    SK = SR[k - 1] + gamma * DS * stpsz  # Current new half-position
                    # ITK = IT(SK)  # Current half-density function
                    # ITK = np.interp(SK, S_samples, density_samples)
                    eval_points[2] = SK
                    if SK < delIT * 0.5:
                        eval_points[0] = SK + delIT
                        eval_points[1] = SK
                    elif SK > S_samples[-1] - delIT * 0.5:
                        eval_points[0] = SK
                        eval_points[1] = SK - delIT
                    else:
                        eval_points[0] = SK + delIT * 0.5
                        eval_points[1] = SK - delIT * 0.5
                    ITK1, ITK2, ITK = interp(eval_points, S_samples, density_samples)
                    dITK = (ITK1 - ITK2) / delIT
                    FRES = ITK - DS  # Current residual
                    dFRES = dITK * gamma * stpsz - 1.0  # Current gradient
                    dDS = -FRES / dFRES  # Newton step

                    conv_cond_residuum = abs(FRES) / DS < 1e-8
                    conv_cond_step = abs(dDS) / DS < 1e-8

                    if conv_cond_step or conv_cond_residuum:
                        subconverged = True
                        break

                    step_max_ratio = 0.2  # Do not make a Newton step larger than 20% of current panel length
                    lam = 1.0
                    lam = min(lam, step_max_ratio * DS / abs(dDS))
                    DS += lam * dDS

                if not subconverged:
                    print(
                        "Paneling Sub-Iteration not converged at k=%u, dDS=%f, dFRes=%f,ITK=%f,dITK=%f"
                        % (k, dDS, dFRES, ITK, dITK)
                    )
                    all_converged = False
                # Derivative of DS with respect to gamma:
                # DS is given by
                # F(DS,S[k-1],gamma) = 0
                # and the derivative of DS with respect to gamma and S is then by implicit function theorem
                F_gam = dITK * (DS * stpsz)
                F_S = dITK
                F_DS = dITK * (gamma * stpsz) - 1
                DS_S = -F_S / F_DS
                DS_gam = -F_gam / F_DS

                if k == 1:
                    DS *= TERat
                    DS_S *= TERat
                    DS_gam *= TERat
            maxDS = max(maxDS, DS)
            minDS = min(minDS, DS)

            SR[k] = SR[k - 1] + gamma * DS
            SEND_GAM += gamma * (DS_S * SEND_GAM + DS_gam) + DS

        dGam = -(SR[-1] - S[-1]) / SEND_GAM

        lam = 1.0
        # Do not change gamma by more than 2.5%
        lam = min(lam, 0.025 / (abs(dGam) / abs(gamma)))
        # Do not change gamma such that the largest DS changes by more than some smallish quantity
        lam = min(lam, 0.005 / (abs(dGam) * maxDS))
        # Do not change gamma by more than 1.5x the fixed point iteration
        lam = min(lam, 1.5 * gamma * abs(S[-1] / SR[-1] - 1) / abs(dGam))

        # Convergence criterium: Difference in length smaller than a fraction of smallest panel
        conv_cond_relTol = abs(SR[-1] - S[-1]) / (minDS * gamma) <= 5e-2
        if it <= iterations_fixed_point:  # First iterations simple fixed-point
            gamma = 0.75*gamma + 0.25*gamma*S[-1] / SR[-1]
        else:  # Probably near solution, use Newton
            gamma += lam * dGam
        if it > iterations_fixed_point and all_converged and conv_cond_relTol:
            converged = True
            break
    if not converged:
        print("Paneling not converged.")

    # Interpolate ArcPoints to new
    XN = np.zeros((2, int(N)))
    XN = spline_eval(X, S, M_spl, SR)
    # No numerical funny business with the TE
    XN[:, 0] = X[:, 0]
    XN[:, -1] = X[:, -1]

    # Rescale
    XN *= XMAX - XMIN
    XN[0, :] += XMIN
    return XN
    # return (XN,S_samples,density_samples) # for debugging, if this is uncommented we can look at the assumed denisty distribution
