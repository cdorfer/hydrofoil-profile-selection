from typing import NamedTuple
from dataclasses import dataclass
import numpy as np


# This class containts all parameters
# It mimics a c struct and needs compatible definition to the cdef class "setupclass"
@dataclass
class setup:
    Re: np.double = 1E6
    Ma: np.double = 0.0
    Ncrit: np.double = 9.0
    Itermax: np.intc = 100
    IterateWakes: np.intc = 0
    Substeps: np.intc = 1
    Silent: np.intc = 0
    Gradients: np.intc = 0
    Alpha: np.double = 0.0
    PitchRate: np.double = 0.0
    LocusA: np.double = 6.75
    LocusB: np.double = 0.83
    ViscPwrExp: np.double = 0.7
    WakeLength: np.double = 1.0
    Tolerance: np.double = 1e-4
    IncompressibleBL: np.intc = 0
    StepsizeLimit: np.double = 1.0
    ShearLagLambdaWake: np.double = .9
    ShearLagLambdaFoil: np.double = 1.0
    HalfWakes: np.intc = 0
    ShearLagType: np.intc = 0
    TransitionStepLimit: np.double = np.inf
    IsCascade: np.intc = 0
    CascadeStaggerAngle: np.double = 0.0
    CascadeStaggerHeight: np.double = 1.0
    ExactAmplificationStart: np.intc = 0
    BypassTransition: np.intc = 1
    FreezeWake: np.intc = 0

    # Do not allow additional fields
    def __setattr__(self, key, value):
        if not hasattr(self, key):
            raise TypeError( "%r does not have an attribute called %r" % (self,key) )
        object.__setattr__(self, key, value)

    # Get datatype of compatible numpy recarray 
    def get_dtype(self):
        return np.dtype({'names': list(self.__annotations__.keys()), 
                     'formats': list(self.__annotations__.values())},align=True)

    # Get a numpy recarray that can directly be cast to a cdef setupclass
    def get_recarray(self):
        return np.rec.fromarrays(self.__dict__.values(),dtype=self.get_dtype(),names=self.__dict__.keys())

    # Helper to get tab-completion while jupyter and colleagues do not fully use dataclasses
    def __dir__(self):
        return ['area', 'perimeter', 'location']